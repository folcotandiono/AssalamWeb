<?php

$host = "localhost";
$db_user = 'asss6297_user';
// $db_user = 'root';
$pass = 'assalam12345';
// $pass = "";
$db_name = 'asss6297_assalam';
// $db_name = "assalam";

$con = mysqli_connect($host,$db_user,$pass,$db_name);

 ?>